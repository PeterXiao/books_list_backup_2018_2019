# What is it?
Compilation from some information resources and presentations related to Java. It contains information which tools to use to check performance of Java application and receipts to resolve some detected issues.

# Which software to use to render MMD file?
It is format of [NBMindMap plugin](http://www.igormaznitsa.com/netbeans-mmd-plugin/), there are plugins for [Intellij](https://plugins.jetbrains.com/plugin/8045) and [NetBeans IDE](http://plugins.netbeans.org/plugin/60188/nb-mindmap-editor), also there is standalone editor [SciaReto](https://github.com/raydac/netbeans-mmd-plugin/releases/latest).
Also there is prerendered PNG version of the mind map in the repository.