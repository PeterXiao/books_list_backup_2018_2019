# 贡献指南

你可以通过以下方式来贡献好看的简历模板：

- 提交 issue
- 提交 PR

To be continued.
