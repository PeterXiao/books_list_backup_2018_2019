# Sidebar CV

*icons using fontawesome
*compile twice to get transparency of statement box

