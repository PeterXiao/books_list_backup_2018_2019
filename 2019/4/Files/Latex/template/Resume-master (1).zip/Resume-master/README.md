Resume
======

个人简历-LaTex
贾艳成

已找到工作；Java研发。

软件安装参考：http://danieljyc.github.io/tags/LaTex/
