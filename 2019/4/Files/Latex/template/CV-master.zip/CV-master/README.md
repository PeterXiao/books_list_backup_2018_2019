# What is this?

A repository for my CV.

# Why on Github?

So that I can keep track of changes and continuosly improve it and/or create diffrent CVs for diffrent needs and fields as I am intrested in **many fields**.

# TODO

- [x] Add the following quote to my CV:

> “I never let my schooling get in the way of my education.”
> — Mark Twain

