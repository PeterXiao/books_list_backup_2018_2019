****

##	<center>中英文个人简历</center>
####	<center>Author: HouJP</center>
####	<center>E-mail: houjp1992@gmail.com</center>

****

###	目录
*	[项目介绍](#intro)
*	[版本更新](#version)
*	[使用说明](#usage)
* 	[参考链接](#link)

****

###	<a name="intro">项目介绍</a>

HouJP的中英文简历，使用latex编译生成。

****

###	<a name="version">版本更新</a>

*	无更新信息

****

###	<a name="usage">使用说明</a>

*	无使用说明


****

###	<a name="link">参考链接</a>

本简历参考自[billryan的模板](https://github.com/billryan/resume/)。