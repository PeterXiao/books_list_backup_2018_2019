WanHu Curriculum Vitæ
=========

LaTeX Template for Curriculum Vitæ
个人中英文简历 LaTeX 模板

-------------

简介
-------------
这是我的个人简历LaTeX模版，包含中英文两个版本。 

源中包含简历TeX源文件、所用的宏包，编译后生成的PDF格式简历模板。

用法
-------------
- 环境：简历在 Ubuntu Linux + TexLive2012-20120701以及Windows 7 + CTeX_2.9.2.164_Full 环境下使用XeLaTeX编译通过。

- 用到的宏包：[moderncv v1.5.1 (2013/04/29)](https://launchpad.net/moderncv/+download)、[fontawesome v3.1.1 (2013/05/10)](http://www.ctan.org/tex-archive/fonts/fontawesome)

- fontawesome字体（[FontAwesome.otf](http://mirrors.ctan.org/fonts/fontawesome/opentype/FontAwesome.otf)）

注：仅中文简历依赖moderncv 宏包，英文可以单独使用。


致谢
-------------
中英文简历模版来自于http://www.latextemplates.com/cat/curricula-vitae ，使用了 Xavier Danaux (xdanaux@gmail.com) 开发的 moderncv.cls、fontawesome宏包。

对原开发者表示感谢!
