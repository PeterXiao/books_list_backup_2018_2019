#!/bin/bash

############################
# Usage:
# File Name: debug.sh
# Author: annhe  
# Mail: i@annhe.net
# Created Time: 2018-05-06 17:55:42
############################

apt-get update
apt-get install --no-install-recommends wget xzdec gnupg perl perl-modules* vim lrzsz
