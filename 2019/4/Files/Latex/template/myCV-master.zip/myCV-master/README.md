#带饼状图的CV模板分享

* 模板参考来源1：http://www.latexstudio.net/extended-fancy-cv-carmine-benedetto-latex-template/
* 模板参考来源2：http://www.latexstudio.net/a-latex-texture-resume-template-sharing/

## 此模板的主要修改工作

1. 加入了对于中文的支持
2. 更加适合于院校毕业生使用
3. 增加了使用tikz绘制自定义的饼状图

## 怎样使用模板
1. 安装文档中的英文字体；
1. 可以通过编辑 **sector.tex** 文件定义自己的饼状图内容。编译后通过skim等PDF工具裁剪为 **img** 文件夹中的式样，记住裁剪后保存为PDF；
2. 编辑cv.tex文件，将对应的内容改成自己的；
3. 记住要使用xelatex编译，windows下需要在导言部分修改中文字体为windows下的字体。


