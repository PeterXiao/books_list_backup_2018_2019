# lean_cv
A lean latex cv template. Create your one page personal CV in almost a minute...

Do add all the missing information to build your resume at template.tex
-- To build the resume XeLaTeX is required.

Enjoy your lean CV!

Hint: Cubeviz does not yet support parametric persentage --> the internal polygon is hard coded. Just provide
the axial information you are interested in in an anticlockwise order starting with the axis ending at the top
right corner.

Future work:
1. Include parametric persentage for the cubviz module in the visualizations.sty package
2. Design a smart way to extend textblocks in more pages.
3. Add publications via bibtex in Appendix.
