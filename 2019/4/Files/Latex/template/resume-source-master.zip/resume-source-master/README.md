resume-source
=============

##使用说明##
- 文件包中的.tex文件为可编辑的源码文件，所有简历内容需要在此类文件中编辑。
- 文件包中的其他文件均为必要文件，在编译中需要包含。
- Windows环境下，执行make.bat文件即可以自动编译生成pdf文件。


>注：此模板来自于网上开源模板[moderncv][1]

[1]:http://www.ctan.org/tex-archive/macros/latex/contrib/moderncv