# v1.0.3
1. 修复wait group的bug
2. 取消merge逻辑

# v1.0.2
1. 更改日志,校验老数据库

# v1.0.1
1. 添加消费者日志
2. movedir

# v1.0.0
1. 新增