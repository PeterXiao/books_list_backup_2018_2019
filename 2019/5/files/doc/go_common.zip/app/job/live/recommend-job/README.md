# live-web-interface

# 项目简介
推荐系统的离线脚本服务

# 编译环境


# 依赖包


# 编译执行

# 部署说明
必须从hadoop拉取数据文件，所以需要hadoop客户端

hadoop客户端从 http://livedev.bilibili.co/download/hadoop-sz.tar.gz 拉取

文件服务部署在 shylf-live-app-27

对于uat环境，
没有分布式hadoop，部署一个http的服务提供单机hadoop的文件下载
