
# v1.0.2
1. 用户信息 multiV3 切换为 account

# v1.0.1
1. waitgroup

# v1.0.0
1. 上线功能xxx
