#### userexp-live service
从直播用户服务中抽离出的单元数据模块、负责用户经验查询、存储。

##### 依赖环境
Go 1.7.5或更高版本

##### API文档
TODO example code api
