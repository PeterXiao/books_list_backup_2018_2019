# v1.0.10
修复user_type的设置

# v1.0.9
1. fix dead  loop
2. pr
# v1.0.8
修复video消费

# v1.0.7
1. 增加video表的state消费，同步修改到topic

# v1.0.6
1. 删除无效方法

# v1.0.5
1. 增加观看历史bloomfilter小时级重建
2. 导入视频删除同步b站同步信息

# v1.0.4
1. 增加binlog补全用户信息
2. merge master

# v1.0.3
1. 添加25w临时导入脚本
2. merge master

# v1.0.2
1. 修改视频导入逻辑
2. merge master
3. 添加 std log

# v1.0.1
1. 添加批量注册评论服务
2. 上线功能xxx

# v1.0.6
1. 删除无效方法
2. 修复
