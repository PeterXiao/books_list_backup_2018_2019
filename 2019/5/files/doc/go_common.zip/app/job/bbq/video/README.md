# video-job

# 项目简介
1.BBQ项目脚本

# 编译环境


# 依赖包


# 编译执行
```bash
# go run main.go -conf test.toml -deploy.env uat
```