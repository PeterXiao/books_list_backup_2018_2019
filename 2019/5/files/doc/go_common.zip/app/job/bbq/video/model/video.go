package model

const (
	//VideoStateOutPut 视频可放出状态
	VideoStateOutPut = "0,1,3,4,5"
)
