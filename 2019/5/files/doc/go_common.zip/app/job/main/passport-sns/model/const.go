package model

// appid
const (
	OldAppID = "101135748"
)

// platform
const (
	PlatformQQ    = 1
	PlatformWEIBO = 2

	PlatformQQStr    = "qq"
	PlatformWEIBOStr = "weibo"
)
