#### workflow job

##### 项目简介

> 1. 用于处理 workflow 的一些异步任务

##### 编译环境

> 请只用golang v1.8.x以上版本编译执行。  

##### 依赖包

> 1. 公共包go-common  
 