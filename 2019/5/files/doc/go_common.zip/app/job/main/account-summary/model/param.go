package model

// ArgMid is
type ArgMid struct {
	Mid int64 `form:"mid" validate:"required"`
}
