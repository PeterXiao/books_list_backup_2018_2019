### app-job

#### Version 1.7.4

> 1.根据aid顺序消费，避免同时收到多条消息时执行顺序不一致

#### Version 1.7.3

> 1.个人空间多机房


#### Version 1.7.2

> 1.个人空间多机房回源

#### Version 1.7.1

> 1.使用account grpc

#### Version 1.7.0
> 1.增加监控sidebar

#### Version 1.6.19

> 1.账号昵称头像变更更新稿件优化

#### Version 1.6.18

> 1.账号昵称头像变更更新稿件

#### Version 1.6.17

> 1.历史排行榜计数更新

#### Version 1.6.6

> 1.历史排行榜计数更新

#### Version 1.6.5

> 1.flush使用批量接口初始化

#### Version 1.6.4

> 1.cpu num

#### Version 1.6.3

> 1.新增稿件缓存刷新功能

#### Version 1.6.2

> 1.稿件计数绝对值更新

#### Version 1.6.1

> 1.http bm

#### Version 1.6.0

> 1.stat切新topic

#### Version 1.5.11

> 1.空间全部投稿缓存换key

#### Version 1.5.10

> 1.fix空间投稿小视频

#### Version 1.5.9

> 1.空间投稿脏mid过滤

#### Version 1.5.8

> 1.补充单元测试

#### Version 1.5.7

> 1.job参数过滤
> 2.fix bug

#### Version 1.5.6

> 1.视频详情页用户投稿job

#### Version 1.5.5

> 1.fix retry

#### Version 1.5.4

> 1.空间投稿异常稿件剔除列表
> 2.error wrap

#### Version 1.5.3

> 1.stat切新databus

#### Version 1.5.2

> 1.去掉旧逻辑代码

#### Version 1.5.1

> 1.去除掉空间投稿中的异常稿件

#### Version 1.5.0

> 1.job自己处理稿件缓存

#### Version 1.4.2

> 1.修复全部投稿panic

#### Version 1.4.1

> 1.修复音频分页bug 

#### Version 1.4.0

> 1.空间全部投稿job重构

#### Version 1.3.8

> 1.修复投稿时间

#### Version 1.3.7

> 1.修复死循环

#### Version 1.3.6

> 1.忽略clip接口错误

#### Version 1.3.5

> 1.空间全量投稿忽略稿件-404返回码修复

#### Version 1.3.4

> 1.空间全量投稿忽略稿件-404返回码

#### Version 1.3.3

> 1.空间全量投稿
> 2.切新的httpclient

#### Version 1.3.2

> 1.切新的httpclient

#### Version 1.3.1

> 1.去掉新旧稿件判断，无脑更新

#### Version 1.3.0

> 1.稿件计数并发消费

#### Version 1.2.11

> 1.初始化稿件id缓存设置过期时间

#### Version 1.2.10

> 1.稿件缓存切新

#### Version 1.2.9

> 1.monitor ping

#### Version 1.2.8

> 1.热门推荐接口切新

#### Version 1.2.7

> 1.修复重试队列的退出

#### Version 1.2.6

> 1.view archive 初始化化功能

#### Version 1.2.1

> 1.archive notify 队列

#### Version 1.2.0

> 1.app-feed灾备缓存
> 2.app-show数据库定时同步

#### Version 1.1.2

> 1.增加sleep

#### Version 1.1.1

> 1.增加定时更新数据库操作

#### Version 1.1.0

> 1.改为同步更新

#### Version 1.0.5

> 1.增加state

#### Version 1.0.4

> 1.修复config和消费问题

#### Version 1.0.2

> 1.增加http monitor ping

#### Version 1.0.0

> 1.基于databus消费更新app-interface缓存
