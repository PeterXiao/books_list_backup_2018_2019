# spider-mm131

## 项目简介
一个精简的爬虫项目，爬取mm131图片

## 依赖
* Maven 3.5.0
* Java 8

## 项目说明
[【爬虫】使用java爬取mm131美女图片](https://segmentfault.com/a/1190000015691227)
