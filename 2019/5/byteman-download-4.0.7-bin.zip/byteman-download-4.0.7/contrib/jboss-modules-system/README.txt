To use:
  add sys:contrib/jboss-modules-system/byteman-jboss-modules-plugin.jar,modules:org.jboss.byteman.modules.jbossmodules.JBossModulesSystem

then place "IMPORT module.name" in the rule
