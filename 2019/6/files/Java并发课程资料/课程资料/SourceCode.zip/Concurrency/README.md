# Concurrency

## Jimin 微信公众号：TechDevPro

不断更新，可以关注并留言自己希望学习的技术

## Jimin 手记地址

http://www.imooc.com/u/5980627/articles

不断更新

## Jimin 实战课程【Java开发企业级权限管理系统】推荐

http://coding.imooc.com/class/149.html


## 课程专属的QQ学习群

Web端"进入课程"，页面右侧会看到QQ群号，验证信息是：购买课程对应的订单号

进群可以额外获得学习一些【课外知识】及【面试知识】

