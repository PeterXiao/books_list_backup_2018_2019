# Concurrency

## Jimin 微信公众号：TechDevPro

不断更新，可以关注并留言自己希望学习的技术

## Jimin 手记地址

http://www.imooc.com/u/5980627/articles

不断更新

## Jimin 实战课程【Java开发企业级权限管理系统】推荐

http://coding.imooc.com/class/149.html


## 课程专属的QQ学习群

Web端"进入课程"，页面右侧会看到QQ群号，验证信息是：购买课程对应的订单号

进群可以额外获得学习一些【课外知识】及【面试知识】

## 课程脑图

### Java并发编程与高并发解决方案
http://naotu.baidu.com/file/6808ea88451b49ba4964e2c81d0d2c8b?token=3a5de17f2ea7220d

### Java开发企业级权限管理系统
http://naotu.baidu.com/file/fe4d0ed0ce3b8dfd9b09263c0f7abf01?token=fdd400eba319d8b7
