package finaltools;

public class F {
	volatile public static int nextPrintWho = 1;
}
