package extthread;

public class MyThread extends Thread {

	@Override
	public void run() {
	}

}
