package entity;

import java.util.ArrayList;
import java.util.List;

public class ValueObject {

	public static List list = new ArrayList();

}
