package tools;

public class Tools {

	public static ThreadLocal tl = new ThreadLocal();

}
