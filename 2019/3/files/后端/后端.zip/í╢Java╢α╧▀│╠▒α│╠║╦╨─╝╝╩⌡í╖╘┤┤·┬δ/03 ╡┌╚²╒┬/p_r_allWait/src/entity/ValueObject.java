package entity;

public class ValueObject {

	public static String value = "";

}
