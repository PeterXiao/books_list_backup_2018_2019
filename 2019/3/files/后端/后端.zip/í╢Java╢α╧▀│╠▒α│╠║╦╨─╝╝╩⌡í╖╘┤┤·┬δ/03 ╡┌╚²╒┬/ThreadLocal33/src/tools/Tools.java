package tools;

import ext.ThreadLocalExt;

public class Tools {
	public static ThreadLocalExt tl = new ThreadLocalExt();
}
