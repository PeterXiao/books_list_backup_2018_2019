package tools;

import java.util.Date;

public class Tools {

	public static ThreadLocal<Date> tl = new ThreadLocal<Date>();

}
