package tools;

import ext.InheritableThreadLocalExt;

public class Tools {
	public static InheritableThreadLocalExt tl = new InheritableThreadLocalExt();
}
