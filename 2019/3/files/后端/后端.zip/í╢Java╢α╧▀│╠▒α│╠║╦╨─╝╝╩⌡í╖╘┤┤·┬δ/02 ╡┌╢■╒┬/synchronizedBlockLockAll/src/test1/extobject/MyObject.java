package test1.extobject;

public class MyObject {
}
