package test;

public class Test {
	public static void main(String[] args) {
		String a = "a";
		String b = "a";
		System.out.println(a == b);
	}
}
