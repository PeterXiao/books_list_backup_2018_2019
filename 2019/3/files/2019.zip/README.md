# blog
some blog coding thinking or rethinking


# JAVA_LINE
JAVA进阶相关书籍：《JAVA并发编程实践》、《Linux Shell脚本攻略》、《spring揭秘 精选版》、《高性能Mysql》、《深入理解Java虚拟机[JVM高级特性与最佳实践](周志明)》、《图解HTTP 彩色版》、《图解TCP_IP_第5版》、《head+first+servlets jsp》、《How Tomcat Works 中文版》、《J2EE核心模式》、《JAVA并发编程实践》

图解TCP_IP_第5版.pdf https://download.csdn.net/download/singgel/10575268

JAVA并发编程实践 https://download.csdn.net/download/singgel/10575062

J2EE核心模式.pdf https://download.csdn.net/download/singgel/10575054

head+first+servlets jsp https://download.csdn.net/download/singgel/10575054

深入理解Java虚拟机[JVM高级特性与最佳实践](周志明) https://download.csdn.net/download/singgel/10575034

从PAXOS到ZOOKEEPER分布式一致性原理与实践 https://download.csdn.net/download/singgel/10575025

effective java https://download.csdn.net/download/singgel/10575008

深入浅出MyBatis技术原理与实战 https://download.csdn.net/download/singgel/10616746

大型网站系统及Java中间件实践 https://download.csdn.net/download/singgel/10621351

深入分析Java Web技术内幕 https://download.csdn.net/download/singgel/10623623

HotSpot实战 https://download.csdn.net/download/singgel/10623740

Java多线程编程核心技术 https://download.csdn.net/download/singgel/10623743

Spring源码深度解析 https://download.csdn.net/download/singgel/10623766

深入解析Spring架构与设计原理 https://download.csdn.net/download/singgel/10637765



http://www.banshujiang.cn/