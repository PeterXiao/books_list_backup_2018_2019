package com.alibaba.p3c.pmd.testframework;

import net.sourceforge.pmd.Rule;
import net.sourceforge.pmd.testframework.SimpleAggregatorTst;

/**
 *
 * @author huawen.phw
 * @date 2018/2/1
 * Description: 扩展framework，runTest支持检查.java文件
 */
public  class ExtendSimpleAggregatorTst extends SimpleAggregatorTst {


}
