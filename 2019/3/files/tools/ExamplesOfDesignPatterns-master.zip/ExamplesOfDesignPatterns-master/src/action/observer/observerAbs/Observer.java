package action.observer.observerAbs;/**
 * Created by MirsFang on 2017/3/3.
 */

/***             
 *作者：MirsFang    
 *模式：观察者模式
 *时间：2017/03/03/下午1:00  
 *备注  你。。。
 ***/

public interface Observer {
    public  void  Update();
}
