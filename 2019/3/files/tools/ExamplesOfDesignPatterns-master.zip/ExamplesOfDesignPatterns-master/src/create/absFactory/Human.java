package create.absFactory;/**
 * Created by MirsFang on 2017/5/5.
 */

/***             
 *作者：MirsFang    
 *模式：抽象工厂
 *时间：2017/05/05/上午10:51  
 *备注  抽象人接口
 ***/

public interface Human {

    public void getColor();

    public void getSex();

}
