# 创建型设计模式

| 包名      | 描述    |
| ------- | ----- |
| builder | 创建者模式 |
|prototype|原型模式|
|singleton|单例模式|
|factory|工厂模式|