package create.factory;/**
 * Created by MirsFang on 2017/5/5.
 */

/***             
 *作者：MirsFang    
 *模式：工厂模式
 *时间：2017/05/05/上午10:15  
 *备注      
 ***/

public interface Human {
    void getColor();
}
