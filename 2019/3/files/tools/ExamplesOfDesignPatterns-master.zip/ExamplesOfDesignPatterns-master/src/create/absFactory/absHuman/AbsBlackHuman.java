package create.absFactory.absHuman;/**
 * Created by MirsFang on 2017/5/5.
 */

/***             
 *作者：MirsFang    
 *模式：       
 *时间：2017/05/05/上午11:19  
 *备注      
 ***/

public class AbsBlackHuman {
}
