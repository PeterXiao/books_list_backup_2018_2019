package create.builder;


/**
 * x战警builder
 * @author Chayne_Shen 2017/3/9 0009.
 *
 */

public interface XManBuilder {
    XManBuilder buildXFactor();
    XManBuilder buildLover();
    XMan buildXman();
}
