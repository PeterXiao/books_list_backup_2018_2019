__author__ = 'dgiles'

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import style
import argparse

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Swingbench results file processor')
    parser.add_argument("-c", "--cpufile", help="The name of the cpu file to parse", required=True)
    args = parser.parse_args()

    cpufile=args.cpufile

    style.use('ggplot')
    nodes = open(cpufile)
    nodeNames = nodes.readline().split(',');
    nodes.close()
    dfraw = pd.read_csv(cpufile,
                        sep=',',
                        skiprows=1,
                        index_col=0,
                        parse_dates=0)
    df = dfraw[0:]
    fig, axs = plt.subplots(nrows=len(nodeNames), ncols=1)
    offset = 0
    for i in range(0, len(nodeNames)):
        columns = df.columns[offset:offset + 3]
        nodedf = df[columns]
        nodedf.plot(kind='area', stacked=True, color=['green', 'red', 'blue'], ax=axs[i], legend=None)
        axs[i].set_ylim(0, 100)
        axs[i].set_ylabel(nodeNames[i], rotation='vertical', fontsize=5)
        if i != len(nodeNames) -1:
            axs[i].get_xaxis().set_visible(False)
        offset = offset + 5

    plt.subplots_adjust(left=0.06, right=0.97, top=0.98, bottom=0.06)
    plt.show()