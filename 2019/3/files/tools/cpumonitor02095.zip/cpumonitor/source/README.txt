To add or modify the monitors provided you'll need to edit the java source code in the com/dom/cpumonitor/osmonitor directory. You can then use "ant" to build a jar file containing new the mew/modified monitors for your operating systems. To run it you'll need to have "java" in your path and ant installed which can be downloaded here.

	http://ant.apache.org/bindownload.cgi

First we'll need to set the environment up. This involves setting a few parameters. The first is "ANT_HOME" which needs to be set to the directory where you downloaded it and the second is simply adding it to the PATH.

 export ANT_HOME=/Users/dgiles/Downloads/apache-ant-1.7.1
 export PATH=$PATH:$ANT_HOME/bin
 
You can test this all works by typing ant -version which should return something like

Apache Ant version 1.7.1 compiled on June 27 2008

Next all you need to type is "ant" and it will use the build.xml file in this directory to create a new set of monitors in a file called mymonitors.jar. It should produce output similar to the following

[dgiles@Doms-macbook source]$ ant
Buildfile: build.xml

init:
    [mkdir] Created dir: /Users/dgiles/java/CPUMonitor/cpumonitor/classes

compile:
    [javac] Compiling 4 source files to /Users/dgiles/java/CPUMonitor/cpumonitor/classes

dist:
      [jar] Building jar: /Users/dgiles/java/CPUMonitor/cpumonitor/mymonitors.jar

BUILD SUCCESSFUL


Thats it.... The default config will pick up any changes you make.

