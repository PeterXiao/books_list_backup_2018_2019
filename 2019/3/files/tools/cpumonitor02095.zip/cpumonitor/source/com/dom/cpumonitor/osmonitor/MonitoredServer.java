package com.dom.cpumonitor.osmonitor;


import com.dom.cpumonitor.LoadInfo;

import com.jcraft.jsch.Session;

import java.util.LinkedHashMap;
import java.util.Map;


public interface MonitoredServer {

  public enum OperatingSystem {

    MacOS,
    Solaris,
    IBMAIX,
    Linux,
    Windows,
    ;

    public static Map<String, OperatingSystem> osMap = new LinkedHashMap<String, OperatingSystem>();
    private static final String MACOS = "Darwin";
    private static final String LINUX = "Linux";
    private static final String SOLARIS = "SunOS";
    private static final String AIX = "AIX";
    private static final String WINDOWS = "Windows";

    static {
      osMap.put(MACOS, MacOS);
      osMap.put(LINUX, Linux);
      osMap.put(SOLARIS, Solaris);
      osMap.put(AIX, IBMAIX);
      osMap.put(WINDOWS, Windows);
    }

    public static OperatingSystem getValue(String value) {
      return osMap.get(value);
    }

  }

  public void setSession(Session session);

  public OperatingSystem getOperatingSystem();

  public void setOS(OperatingSystem operatingSystem);

  public LoadInfo getLastReading();

  public void setHostname(String hostname);

  public String getHostname();

  public void setCPUCount(int cpuCount);

  public int getCPUCount();

  public void setProcessorType(String processorType);

  public String getProcessorType();

  public void setProcesorSpeed(String processorSpeed);

  public String getProcessorSpeed();

  public void setMemory(String memory);

  public String getMemory();

  public String getComment();

  public void setComment(String comment);

  public boolean isInitialising();

  public void setRefreshRate(long refreshRate);

  public long getRefreshRate();
  
  public void close();

}
