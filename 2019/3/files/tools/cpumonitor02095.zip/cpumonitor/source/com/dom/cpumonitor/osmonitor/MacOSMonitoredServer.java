package com.dom.cpumonitor.osmonitor;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;

import java.util.logging.*;
import java.util.StringTokenizer;
import java.util.logging.Logger;


public class MacOSMonitoredServer extends MonitoredServerImpl {
  
  private static final Logger logger = Logger.getLogger(MacOSMonitoredServer.class.getName());

  public MacOSMonitoredServer() {
    super();
    thisThread = new Thread(this, "MonitorThread" + threadId++);
    thisThread.start();
  }

  public MacOSMonitoredServer(Session session) throws Exception {
    super();
    this.session = session;
    thisThread = new Thread(this, "MonitorThread" + threadId++);
    thisThread.start();
  }

  @Override
  public void init() throws Exception {
    logger.finest(thisThread.getName() + "Starting init()");
    String command = "system_profiler -detailLevel mini | egrep 'Number.Of.Processors:|Memory: |Processor.Name|Processor.Speed'";
    Channel channel = session.openChannel("exec");
    ((ChannelExec)channel).setCommand(command);
    channel.setInputStream(null);
    ((ChannelExec)channel).setErrStream(System.err);
    channel.connect();
    InputStream ins = channel.getInputStream();
    logger.finest(thisThread.getName() + " executed => " + command);
    byte[] tmp = new byte[1024];
    StringBuffer sb = new StringBuffer();
    // Read data rembering the channel is closed at some staqe.
    readData:
    while (true) {
      while (ins.available() > 0) {
        int i = ins.read(tmp, 0, 1024);
        if (i < 0)
          break readData;
        sb.append(new String(tmp, 0, i));
      }
      if (channel.isClosed()) {
        break readData;
      }
    }
    channel.disconnect();
    logger.finest(thisThread.getName() + " data read and channel disconneceted " + sb);
    String pn = null;
    String ps = null;
    String np = null;
    String me = null;
    BufferedReader in = new BufferedReader(new StringReader(sb.toString()));
    String sos;
    while ((sos = in.readLine()) != null) {
      sos = sos.trim();
      if (sos.startsWith("Processor Name:")) {
        pn = sos.substring(sos.indexOf(':') + 1, sos.length());
      } else if (sos.startsWith("Processor Speed:")) {
        ps = sos.substring(sos.indexOf(':') + 1, sos.length());
      } else if (sos.startsWith("Number Of Processors:")) {
        np = sos.substring(sos.indexOf(':') + 1, sos.length()).trim();
      } else if (sos.startsWith(("Memory:"))) {
        me = sos.substring(sos.indexOf(':') + 1, sos.length());
      }
    }
    logger.finest(thisThread.getName() + " parsed data");
    int npi = 1;
    try {
      if (np != null) {
        logger.finest(thisThread.getName() + " parsing " + np);
        npi = Integer.parseInt(np);
      } else {
        throw new Exception("Processor count is null");
      }
    } catch (Exception e) {
      logger.log(Level.INFO,"Failed to parse : " + np);
      
    }
    this.setCPUCount(npi);
    this.setProcesorSpeed(ps);
    this.setProcessorType(pn);
    this.setHostname(hostname);
    this.setMemory(me);
    initialising = false;
    logger.finest(thisThread.getName() + " finished init()");
  }

  @Override
  public void run() {
    try {
      init();

      StringTokenizer st;

      String command = "iostat -w" + refreshRate + " -n 1";
      Channel channel = session.openChannel("exec");
      ((ChannelExec)channel).setCommand(command);
      channel.setInputStream(null);
      ((ChannelExec)channel).setErrStream(System.err);
      BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));
      channel.connect();

      logger.finest(thisThread.getName() + " executing command = > " + command);

      in.readLine();
      st = new StringTokenizer(in.readLine());

      String token;
      int idleLoc = -1;
      int sysLoc = -1;
      int usrLoc = -1;
      int iopLoc = -1;

      for (int i = 0; st.hasMoreTokens(); i++) {
        token = st.nextToken();

        if (token.equals("us")) {
          usrLoc = i;
        } else if (token.equals("sy")) {
          sysLoc = i;
        } else if (token.equals("id")) {
          idleLoc = i;
        } else if (token.equals("MB/s")) {
          iopLoc = i;
        }
      }

      in.readLine(); // discard nonsense values (cpu load average over uptime)

      int idle = 0;

      boolean running = true;
      while (running) {
        st = new StringTokenizer(in.readLine());

        try {
          Double.parseDouble(st.nextToken());
        } catch (NumberFormatException nfe) {
          continue;
        }

        int usr = 0;
        int sys = 0;
        int iops = 0;

        for (int i = 1; st.hasMoreTokens(); i++) {
          token = st.nextToken();

          if (i == idleLoc) {
            idle = Integer.parseInt(token);
            lastReading.setIdle(idle);
          } else if (i == usrLoc) {
            usr = Integer.parseInt(token);
            lastReading.setUsr(usr);
          } else if (i == sysLoc) {
            sys = Integer.parseInt(token);
            lastReading.setSys(sys);
          } else if (i == iopLoc) {
            iops = (int)(Float.parseFloat(token) * 1024);
            lastReading.setBi(iops);
          }
        }

      }
      channel.disconnect();
      session.disconnect();
      logger.finest(thisThread.getName() + " disconnecting channel and session");
    } catch (Exception e) {
      logger.log(Level.INFO,"Exception in run() :", e);
    }
  }

}
