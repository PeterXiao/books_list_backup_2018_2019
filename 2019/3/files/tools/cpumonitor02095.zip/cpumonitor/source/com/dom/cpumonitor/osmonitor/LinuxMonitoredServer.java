package com.dom.cpumonitor.osmonitor;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;

import java.text.NumberFormat;

import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;


public class LinuxMonitoredServer extends MonitoredServerImpl {

    private static final Logger logger = Logger.getLogger(LinuxMonitoredServer.class.getName());


    public LinuxMonitoredServer() {
        super();
        Thread thisThread = new Thread(this);
        thisThread.start();
    }

    public LinuxMonitoredServer(Session session) throws Exception {
        super();
        logger.entering(LinuxMonitoredServer.class.getName(), "LinuxMonitoredServer");
        this.session = session;
        Thread thisThread = new Thread(this);
        thisThread.start();
        logger.exiting(LinuxMonitoredServer.class.getName(), "LinuxMonitoredServer");
    }

    public void init() throws Exception {

        logger.entering(LinuxMonitoredServer.class.getName(), "init");
        String command = "echo -n 'Number Of Processors: '; cat /proc/cpuinfo | grep processor | wc -l; cat /proc/cpuinfo | egrep -m 2 'cpu MHz|model name';cat  /proc/meminfo | grep MemTotal:";
        Channel channel = session.openChannel("exec");
        ((ChannelExec)channel).setCommand(command);
        channel.setInputStream(null);
        ((ChannelExec)channel).setErrStream(System.err);
        channel.connect();
        InputStream ins = channel.getInputStream();
        byte[] tmp = new byte[1024];
        StringBuffer sb = new StringBuffer();
        // Read data rembering the channel is closed at some staqe.
        readData:
        while (true) {
            while (ins.available() > 0) {
                int i = ins.read(tmp, 0, 1024);
                if (i < 0)
                    break readData;
                sb.append(new String(tmp, 0, i));
            }
            if (channel.isClosed()) {
                break readData;
            }
        }
        channel.disconnect();
        String pn = null;
        String ps = null;
        String np = null;
        String me = null;
        BufferedReader in = new BufferedReader(new StringReader(sb.toString()));
        String sos;
        while ((sos = in.readLine()) != null) {
            sos = sos.trim();
            if (sos.startsWith("model name")) {
                try {
                    pn = sos.substring(sos.indexOf(':') + 1, sos.length());
                    pn = pn.substring(0, pn.indexOf("CPU")).trim();
                    logger.finest(pn);
                } catch (Exception e) {
                    logger.finest("Model parse issue");
                }
            } else if (sos.startsWith("cpu MHz")) {
                try {
                    ps = sos.substring(sos.indexOf(':') + 1, sos.length()).trim();
                    double psd = Double.parseDouble(ps) / 1000;
                    NumberFormat nf = NumberFormat.getNumberInstance();
                    nf.setMaximumFractionDigits(2);
                    ps = nf.format(psd) + " GHz";
                    logger.finest(ps);
                } catch (Exception e) {
                    logger.finest("Processor speed parse issue");
                }
            } else if (sos.startsWith("Number Of Processors:")) {
                try {
                    np = sos.substring(sos.indexOf(':') + 1, sos.length()).trim();
                    logger.finest(np);
                } catch (Exception e) {
                    logger.finest("Number of Processors parse issue");
                }
            } else if (sos.startsWith(("MemTotal:"))) {
                try {
                    me = sos.substring(sos.indexOf(':') + 1, sos.length());
                    me = me.substring(0, me.indexOf("kB")).trim();
                    int mei = Integer.parseInt(me);
                    me = (mei / 1024) + " MB";
                    logger.finest(me);
                } catch (Exception e) {
                    logger.finest("Memory parse issue");
                }
            }
        }
        int npi = Integer.parseInt(np);
        this.setCPUCount(npi);
        this.setProcesorSpeed(ps);
        this.setProcessorType(pn);
        this.setHostname(hostname);
        this.setMemory(me);
        initialising = false;
        logger.exiting(LinuxMonitoredServer.class.getName(), "init");
    }

    public void run() {
        logger.entering(LinuxMonitoredServer.class.getName(), "run");
        try {
            StringTokenizer st;

            try {
                init();
            } catch (Exception e) {
                logger.log(Level.FINEST, "Exception thrown by init()", e);
            }

            String command = "vmstat " + refreshRate;

            Channel channel = session.openChannel("exec");
            ((ChannelExec)channel).setCommand(command);

            channel.setInputStream(null);

            ((ChannelExec)channel).setErrStream(System.err);

            BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));

            channel.connect();

            in.readLine();
            st = new StringTokenizer(in.readLine());

            String token;
            int idleLoc = -1;
            int sysLoc = -1;
            int usrLoc = -1;
            int waitLoc = -1;
            int biLoc = -1;
            int boLoc = -1;

            for (int i = 0; st.hasMoreTokens(); i++) {
                token = st.nextToken();

                if (token.equals("id")) {
                    idleLoc = i;
                } else if (token.equals("us")) {
                    usrLoc = i;
                } else if (token.equals("sy")) {
                    sysLoc = i;
                } else if (token.equals("wa")) {
                    waitLoc = i;
                } else if (token.equals("bi")) {
                    biLoc = i;
                } else if (token.equals("bo")) {
                    boLoc = i;
                }
            }

            in.readLine(); // nonsense values (cpu load average over uptime)

            int idle = 0;
            boolean running = true;
            while (running) {
                st = new StringTokenizer(in.readLine());

                try {
                    Integer.parseInt(st.nextToken());
                } catch (NumberFormatException nfe) {
                    continue;
                }

                int usr = 0;
                int sys = 0;
                int wait = 0;
                int bo = 0;
                int bi = 0;

                for (int i = 1; st.hasMoreTokens(); i++) {
                    token = st.nextToken();
                    lastReading.setTime(System.currentTimeMillis());
                    if (i == idleLoc) {
                        idle = Integer.parseInt(token);
                        lastReading.setIdle(idle);
                    } else if (i == usrLoc) {
                        usr = Integer.parseInt(token);
                        lastReading.setUsr(usr);
                    } else if (i == sysLoc) {
                        sys = Integer.parseInt(token);
                        lastReading.setSys(sys);
                    } else if (i == waitLoc) {
                        wait = Integer.parseInt(token);
                        lastReading.setWait(wait);
                    } else if (i == biLoc) {
                        bi = Integer.parseInt(token);
                        lastReading.setBi(bi);
                    } else if (i == boLoc) {
                        bo = Integer.parseInt(token);
                        lastReading.setBo(bo);
                    }
                }
            }
            channel.disconnect();
            session.disconnect();
            logger.exiting(LinuxMonitoredServer.class.getName(), "run");
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Unexpected Exception in run()", e);
        }
    }


}
