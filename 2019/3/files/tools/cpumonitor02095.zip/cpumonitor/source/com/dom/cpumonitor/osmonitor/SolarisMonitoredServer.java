package com.dom.cpumonitor.osmonitor;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;

import java.text.NumberFormat;

import java.util.logging.*;
import java.util.StringTokenizer;

public class SolarisMonitoredServer extends MonitoredServerImpl {
  
  private static final Logger logger = Logger.getLogger(SolarisMonitoredServer.class.getName());

  public SolarisMonitoredServer() {
    super();
    Thread thisThread = new Thread(this);
    thisThread.start();
  }

  public SolarisMonitoredServer(Session session) throws Exception {
    super();
    this.session = session;
    Thread thisThread = new Thread(this);
    thisThread.start();
  }
  
  @Override
  public void init() throws Exception {
    logger.finest("Starting init()");
    String command = "echo -n 'Number Of Processors: '; /usr/sbin/psrinfo | wc -l;/usr/sbin/psrinfo -v | egrep 'MHz' | head -1; /usr/sbin/prtconf | grep Memory";
//    Number Of Processors:        1
//      The i386 processor operates at 588 MHz,
//    Memory size: 768 Megabytes
    Channel channel = session.openChannel("exec");
    ((ChannelExec)channel).setCommand(command);
    channel.setInputStream(null);
    ((ChannelExec)channel).setErrStream(System.err);
    channel.connect();
    InputStream ins = channel.getInputStream();
    byte[] tmp = new byte[1024];
    StringBuffer sb = new StringBuffer();
    // Read data rembering the channel is closed at some staqe.
    readData:
    while (true) {
      while (ins.available() > 0) {
        int i = ins.read(tmp, 0, 1024);
        if (i < 0)
          break readData;
        sb.append(new String(tmp, 0, i));
      }
      if (channel.isClosed()) {
        break readData;
      }
    }
    channel.disconnect();
    String pn = null;
    String ps = null;
    String np = null;
    String me = null;
    BufferedReader in = new BufferedReader(new StringReader(sb.toString()));
    String sos;
    while ((sos = in.readLine()) != null) {
      sos = sos.trim();
      if (sos.startsWith("The")) {
        try {
          pn = sos.substring(3, sos.indexOf("processor")).trim();
          logger.finest(pn);
          ps = sos.substring(sos.indexOf(" at ") + 3, sos.indexOf("MHz")).trim();
          double psd = Double.parseDouble(ps) / 1000;
          NumberFormat nf = NumberFormat.getNumberInstance();
          nf.setMaximumFractionDigits(2);
          ps = nf.format(psd) + " GHz";
          logger.finest(ps);
        } catch (Exception e) {
          logger.log(Level.INFO,"Processor speed parse issue");
        }
      } else if (sos.startsWith("Number Of Processors:")) {
        try {
          np = sos.substring(sos.indexOf(':') + 1, sos.length()).trim();
          logger.finest(np);
        } catch (Exception e) {
          logger.log(Level.INFO,"Number of Processors parse issue " + e.getMessage());
        }
      } else if (sos.startsWith(("Memory"))) {
        try {
          me = sos.substring(sos.indexOf(':') + 1, sos.length());
          me = me.substring(0, me.indexOf("Megabytes")).trim();
          //int mei = Integer.parseInt(me);
          me = me + " MB";
          logger.finest(me);
        } catch (Exception e) {
          logger.log(Level.INFO,"Memory parse issue");
        }
      }
    }
    int npi = Integer.parseInt(np);
    this.setCPUCount(npi);
    this.setProcesorSpeed(ps);
    this.setProcessorType(pn);
    this.setHostname(hostname);
    this.setMemory(me);
    initialising = false;
  }

  @Override
  public void run() {
    try {
      try {
        init();
      } catch (Exception e) {
        logger.log(Level.INFO,"Exception thrown by init()", e);
      }

      StringTokenizer st;

      String command = "iostat " + refreshRate;

      Channel channel = session.openChannel("exec");
      ((ChannelExec)channel).setCommand(command);

      channel.setInputStream(null);

      ((ChannelExec)channel).setErrStream(System.err);

      BufferedReader in = new BufferedReader(new InputStreamReader(channel.getInputStream()));

      channel.connect();

      in.readLine();
      st = new StringTokenizer(in.readLine());

      String token;
      int idleLoc = -1;
      int sysLoc = -1;
      int usrLoc = -1;
      int waitLoc = -1;
      int boLoc = -1;
      boolean kpsFound = false;

      for (int i = 0; st.hasMoreTokens(); i++) {
        token = st.nextToken();

        if (token.equals("us")) {
          usrLoc = i;
        } else if (token.equals("sy")) {
          sysLoc = i;
        } else if (token.equals("wt")) {
          waitLoc = i;
        } else if (token.equals("kps") && !kpsFound) { // only read first kps entry. 
          boLoc = i;
          kpsFound = true;
        } 
      }

      in.readLine(); // nonsense values (cpu load average over uptime)

      int idle = 0;
      boolean running = true;
      while (running) {
        st = new StringTokenizer(in.readLine());

        try {
          Integer.parseInt(st.nextToken());
        } catch (NumberFormatException nfe) {
          continue;
        }

        int usr = 0;
        int sys = 0;
        int wait = 0;
        int bo = 0;

        for (int i = 1; st.hasMoreTokens(); i++) {
          token = st.nextToken();

          if (i == usrLoc) {
            usr = Integer.parseInt(token);
            lastReading.setUsr(usr);
          } else if (i == sysLoc) {
            sys = Integer.parseInt(token);
            lastReading.setSys(sys);
          } else if (i == waitLoc) {
            wait = Integer.parseInt(token);
            lastReading.setWait(wait);
          } else if (i == boLoc) {
            bo = Integer.parseInt(token);
            lastReading.setBi(bo);
          }
        }
      }
      channel.disconnect();
      session.disconnect();
    } catch (Exception e) {
      logger.log(Level.INFO,"Unexpected Exception in run()", e);
    }
  }

}
