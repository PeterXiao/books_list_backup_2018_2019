package com.dom.cpumonitor.osmonitor;


import com.dom.cpumonitor.LoadInfo;

import com.jcraft.jsch.Session;


public abstract class MonitoredServerImpl implements MonitoredServer, Runnable {

  protected static int threadId = 1;
  protected Thread thisThread = null;
  protected LoadInfo lastReading = new LoadInfo(this);
  protected long refreshRate = 1;
  protected Session session = null;
  protected MonitoredServer.OperatingSystem operatingSystem = null;
  protected String hostname = null;
  protected int cpuCount = 1;
  protected String memory = null;
  protected String processorType;
  protected String processorSpeed;
  protected String comment;
  protected boolean initialising = true;
  
  public MonitoredServerImpl() {
  }
  
  
  public MonitoredServerImpl(Session session) throws Exception { 
  }

  public void setProcessorType(String processorType) {
    this.processorType = processorType;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setSession(Session session) {
    this.session = session;
  }

  public int getCPUCount() {
    return cpuCount;
  }

  public String getMemory() {
    return memory;
  }

  public String getProcessorType() {
    return processorType;
  }

  public MonitoredServer.OperatingSystem getOperatingSystem() {
    return this.operatingSystem;
  }

  public String getHostname() {
    return hostname;
  }

  public void setRefreshRate(long refreshRate) {
    this.refreshRate = refreshRate;
  }

  public void setProcesorSpeed(String procesorSpeed) {
    this.processorSpeed = procesorSpeed;
  }

  public void setHostname(String hostname) {
    this.hostname = hostname;
  }

  public void setMemory(String memory) {
    this.memory = memory;
  }

  public LoadInfo getLastReading() {
    return lastReading;
  }

  public String getComment() {
    return comment;
  }

  public void setCPUCount(int cpuCount) {
    this.cpuCount = cpuCount;
  }

  public boolean isInitialising() {
    return initialising;
  }

  public String getProcessorSpeed() {
    return processorSpeed;
  }

  public long getRefreshRate() {
    return refreshRate;
  }

  public void setOS(MonitoredServer.OperatingSystem operatingSystem) {
    this.operatingSystem = operatingSystem;
  }
 

  public void init() throws Exception {
    
  }

  public void run() {
    
  }
  
  public void close() {
    session.disconnect();
  }

}
