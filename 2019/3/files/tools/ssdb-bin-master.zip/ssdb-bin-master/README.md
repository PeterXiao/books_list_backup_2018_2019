ssdb-bin
========

SSDB pre-compiled executable binary for Windows.

__SSDB for win is for development only, do not use it for production environment!__

# Installation and Setup

1. Download ssdb-server.exe and \*.dll files from https://github.com/ideawu/ssdb-bin
2. Download ssdb.conf from https://github.com/ideawu/ssdb
3. Run cmd.exe from Start menu
4. Go into the folder where ssdb-server.exe resides in
5. Run ssdb-server.exe ssdb.conf
 
Now the ssdb-server is started on Windows, connect to it with PHP, Python, Java, etc...

# SSDB on Windows without cygwin

Maintained by [@RelicOfTesla](https://github.com/RelicOfTesla), this version does not rely on cygwin, so it is fast, and is said to be ready for production on Windows.

https://github.com/RelicOfTesla/ssdb



