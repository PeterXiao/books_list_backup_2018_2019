
# 简介

这里存放着本人平时以思维导图形式整理的相关资料信息，如有引用和转载，请注明出处。

# XMind

需要安装免费的[XMind思维导图软件](http://www.xmindchina.net/)，才能打开相应的文件。

----------

# 目录

## git ##

Git.jpg

Git.xmind

分支管理策略.png

分支管理策略.svg

## javascript ##

ECMAScript 6.jpg

ECMAScript6.xmind

requirejs.jpg

requirejs.xmind

TypeScript.jpg

TypeScript.xmind

__proto__与prototype.jpg

__proto__与prototype.xmind

高性能javascript.jpg

高性能javascript.xmind

## 设计模式 ##

23种设计模式.jpg

23种设计模式.xmind

设计原则.jpg

设计原则.xmind

----------
本目录更新时间：Fri Oct 07 2016 09:36:04 GMT+0800 (中国标准时间)
