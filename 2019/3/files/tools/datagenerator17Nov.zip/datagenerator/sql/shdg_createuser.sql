CREATE USER &username IDENTIFIED BY &password;

ALTER USER &username DEFAULT TABLESPACE &tablespace QUOTA UNLIMITED ON &tablespace;

ALTER USER &username TEMPORARY TABLESPACE TEMP;

GRANT CONNECT TO &username;

GRANT RESOURCE TO &username;

GRANT CREATE VIEW to &username;

GRANT CREATE MATERIALIZED VIEW  TO &username;

GRANT QUERY REWRITE TO &username;

GRANT ALTER SESSION TO &username;

GRANT EXECUTE ON dbms_lock TO &username;


