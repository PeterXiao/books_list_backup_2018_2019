drop table CHANNELS cascade constraints purge;

drop table CUSTOMERS cascade constraints purge;

drop table COUNTRIES cascade constraints purge;

drop table PROMOTIONS cascade constraints purge;

drop table PRODUCTS cascade constraints purge;

drop table SUPPLEMENTARY_DEMOGRAPHICS cascade constraints purge;

drop table TIMES cascade constraints purge;

drop table COSTS cascade constraints purge;

drop table SALES cascade constraints purge;



