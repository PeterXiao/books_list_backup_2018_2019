drop view SUPPLEMENTARY_DEMOGRAPHICS16;

drop view SUPPLEMENTARY_DEMOGRAPHICS15;

drop view SUPPLEMENTARY_DEMOGRAPHICS14;

drop view SUPPLEMENTARY_DEMOGRAPHICS13;

drop view SUPPLEMENTARY_DEMOGRAPHICS12;

drop view SUPPLEMENTARY_DEMOGRAPHICS11;

drop view SUPPLEMENTARY_DEMOGRAPHICS10;

drop view SUPPLEMENTARY_DEMOGRAPHICS9;

drop view SUPPLEMENTARY_DEMOGRAPHICS8;

drop view SUPPLEMENTARY_DEMOGRAPHICS7;

drop view SUPPLEMENTARY_DEMOGRAPHICS6;

drop view SUPPLEMENTARY_DEMOGRAPHICS5;

drop view SUPPLEMENTARY_DEMOGRAPHICS4;

drop view SUPPLEMENTARY_DEMOGRAPHICS3;

drop view SUPPLEMENTARY_DEMOGRAPHICS2;

drop view SUPPLEMENTARY_DEMOGRAPHICS1;

drop view CUSTOMERS16;

drop view CUSTOMERS15;

drop view CUSTOMERS14;

drop view CUSTOMERS13;

drop view CUSTOMERS12;

drop view CUSTOMERS11;

drop view CUSTOMERS10;

drop view CUSTOMERS9;

drop view CUSTOMERS8;

drop view CUSTOMERS7;

drop view CUSTOMERS6;

drop view CUSTOMERS5;

drop view CUSTOMERS4;

drop view CUSTOMERS3;

drop view CUSTOMERS2;

drop view CUSTOMERS1;

drop view SALES_Q4_2012;

drop view SALES_Q3_2012;

drop view SALES_Q2_2012;

drop view SALES_Q1_2012;

drop view SALES_Q4_2011;

drop view SALES_Q3_2011;

drop view SALES_Q2_2011;

drop view SALES_Q1_2011;

drop view SALES_Q4_2010;

drop view SALES_Q3_2010;

drop view SALES_Q2_2010;

drop view SALES_Q1_2010;

drop view SALES_Q4_2009;

drop view SALES_Q3_2009;

drop view SALES_Q2_2009;

drop view SALES_Q1_2009;

drop view SALES_Q4_2008;

drop view SALES_Q3_2008;

drop view SALES_Q2_2008;

drop view SALES_Q1_2008;

drop view SALES_Q4_2007;

drop view SALES_Q3_2007;

drop view SALES_Q2_2007;

drop view SALES_Q1_2007;

drop view SALES_Q4_2006;

drop view SALES_Q3_2006;

drop view SALES_Q2_2006;

drop view SALES_Q1_2006;

drop view SALES_Q4_2005;

drop view SALES_Q3_2005;

drop view SALES_Q2_2005;

drop view SALES_Q1_2005;

drop view SALES_Q4_2004;

drop view SALES_Q3_2004;

drop view SALES_Q2_2004;

drop view SALES_Q1_2004;

drop view SALES_Q4_2003;

drop view SALES_Q3_2003;

drop view SALES_Q2_2003;

drop view SALES_Q1_2003;

drop view SALES_Q4_2002;

drop view SALES_Q2_2001;

drop view SALES_Q3_2002;

drop view SALES_Q2_2002;

drop view SALES_Q1_2002;

drop view SALES_Q4_2001;

drop view SALES_Q3_2001;

drop view SALES_Q1_2001;

drop view SALES_Q4_2000;

drop view SALES_Q3_2000;

drop view SALES_Q2_2000;

drop view SALES_Q1_2000;

drop view SALES_Q4_1999;

drop view SALES_Q3_1999;

drop view SALES_Q2_1999;

drop view SALES_Q1_1999;

drop view SALES_Q4_1998;

drop view SALES_Q3_1998;

drop view SALES_Q2_1998;

drop view SALES_Q1_1998;

drop view SALES_H2_1997;

drop view SALES_H1_1997;

drop view SALES_1996;

drop view SALES_1995;

-- End;


