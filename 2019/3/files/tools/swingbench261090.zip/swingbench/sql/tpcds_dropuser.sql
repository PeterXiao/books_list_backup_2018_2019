-- Drop the TPCDS Like user

drop user &username cascade;

-- End
