from __future__ import print_function

import argparse
import os
import re
import xml.etree.ElementTree as ET
import traceback


def get_namespace(element):
    m = re.match('\{.*\}', element.tag)
    return m.group(0) if m else ''


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Enable/Disable TPCDS queries')
    parser.add_argument("-c", "--config", help="The pathname of the tpcds_statements.xml file", required=True, nargs='*')
    parser.add_argument("-s", "--statement", help="The name of the query")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-e", "--enable", help="Enable statement", action='store_true', dest='set_status')
    group.add_argument("-d", "--disable", help="Disable statement", action='store_false', dest='set_status')
    args = parser.parse_args()

    try:
        xmlfile = args.config[0]

        transactions = set()

        file = open(xmlfile, 'r')
        tree = ET.parse(file)
        root = tree.getroot()
        namespace = get_namespace(root)

        found_enabled = root.find(".//{0}{1}[{0}name='{2}']/{0}enabled".format(namespace, 'SQLStatement', args.statement))
        found_enabled.text = str(args.set_status).lower()

        file.close()

        tree = ET.ElementTree(root)

        os.rename(xmlfile, xmlfile + '.bak')
        file = open(xmlfile, 'w')
        tree.write(xmlfile,
                   xml_declaration=True, encoding='utf-8',
                   method="xml", default_namespace='http://www.dominicgiles.com/swingbench/SQLStatements')
        print("Query {} has had it's enabled status set to {}".format(args.statement, args.set_status))
    except Exception as e:
        print("Failed to enable/disable {}".format(args.statement))
        print(traceback.format_exc())
