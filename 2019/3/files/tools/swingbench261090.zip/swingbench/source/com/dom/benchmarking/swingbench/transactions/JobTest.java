package com.dom.benchmarking.swingbench.transactions;

/**
 * Created by dgiles on 10/03/2016.
 */
public class JobTest {
}
