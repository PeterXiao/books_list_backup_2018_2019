# appseceu2017-latex
LaTeX template mimicking the PowerPoint template for the OWASP AppSecEU 2017
conference in Belfast.

## License
If not otherwise stated, all sub-projects are dual-licensed under a
2-clause BSD-style license and/or the LPPL version 1 or any later 
version. 
