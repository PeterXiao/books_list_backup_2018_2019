## 以华中科技大学主题的幻灯片模板
1. 借助 [华中师范大学幻灯片模板 1.0](https://github.com/K-JW/CCNU_BeamerTemplate) 修改。
2. 目前尚不完善，例如华中科技大学的标题（cgcl_title1.png）没P好（手残）。
