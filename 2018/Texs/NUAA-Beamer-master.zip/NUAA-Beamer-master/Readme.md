＃ NUAA-Beamer  
---
南航主题的LaTex Beamer模版   
初步计划在[THUBeamer](https://github.com/tl3shi/THUBeamer)基础上进行修改  

## log:  
2018/03/01 13:53:14 修改了导言区设置，对文档中的英文使用Times字体，对数学公式使用professionalfonts字体主题  
2018/02/26 10:12:51 修改了thubeamer.sty中的配色 
\xdefinecolor{nuaa}{rgb}{0.0,0.415,0.682}  %RGB #006aae (0,106,174)  

## 编译   
xelatex nuaa.tex
