# easy\_slides

Easy slides template for LaTeX users, based on the article class.

Introduction (in Chinese): <https://liam.page/2018/10/29/easy-slides-template/>
