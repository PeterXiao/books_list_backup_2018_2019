# LaTeX Beamer: Singapore-940 (sgp940)

A LaTeX beamer template based on Singapore theme

* `sgp940.tex`: This is a latex source file using the the style `sgp940.sty` (in line 2).
* `sgp940.sty`: This is the style file cited by `sgp940.tex`.

The above two files should be put in the same folder.

**Recommended compiler:** XeLaTeX (in TeXstudio, find `Configure TeXstudio` function, choose `Build` in left sidebar, change `Default Compiler` to `XeLaTeX`.)
