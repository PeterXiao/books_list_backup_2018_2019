# coventry_beamer

Put all files in your...
$TEXMF/tex/latex/beamer/base/themes/theme 
...folder

Shared or local user it doesn't matter but if local user it would be...
/home/$USER/texmf/tex/latex/beamer/base/themes/theme
