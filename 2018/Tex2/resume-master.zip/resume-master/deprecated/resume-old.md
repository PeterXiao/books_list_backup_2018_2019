ice1000 ([ice1000@kotliner.cn](mailto:ice1000@kotliner.cn))
---

<p/>|<p/>
:---|:---
Familiar Platforms|**Java Virtual Machine<br/>JetBrains MetaProgrammingSystem<br/>Java Native Interface**
Education|**ChengDu Foreign Languages School**, 2015.9 - present
GitHub|https://github.com/ice1000<br/>https://github.com/icela<br/>https://github.com/lice-lang
Projects|An algorithm library for Java usage, JNI implemented:<br/>https://github.com/ice1000/algo4j<br/>A 'cross-language(Java, C#, etc.)' game engine for educational usage<br/>https://github.com/icela<br/>A Lisp interpreter, which can interact with Java, as easy as Lua and C<br/>https://github.com/lice-lang/lice
Java/Kotlin|**1 year of experience**<br/><br/>These two languages are mostly used<br/>Java is too weak, so I use Kotlin
Other languages|See this GitHub repo for further information:<br/>https://github.com/ice1000/learn
Books studied|*Compilers: Principles, Techniques and Tools(About parsing only)<br/>Structure and Interpretaion of Computer Programs<br/>Metaprogramming Ruby<br/>Functional Programming in Scala<br/>Core Java I and II, 9th Edition<br/>*
Interests|Programming Languages<br/>Language-Oriented Programming<br/>Functional Programming<br/>




